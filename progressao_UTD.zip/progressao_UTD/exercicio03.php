<div class="container-fluid">
        <div class="row">
          <div class="col-2"></div>
          <div class="clo-8">
            <h1 class="texte-cente">Formulário</h1><hr>
            <div class="row">
                <form action="recebe.php" method="GET">

                    <div class="mb-3 col-4">
                        <label for="text" class="form-label">
                        <span>Nome</span>
                        </label>
                        <input type="text" class="form-control" id="nome completo" placeholder="Digite seu nome" name="nome">
                    </div>

                    <div class="mb-3 col-4">
                        <label for="text" class="form-label">
                        <span>Sobrenome</span>
                        </label>
                        <input type="text" class="form-control" id="nome completo" placeholder="Digite seu sobrenome" name="sobrenome">
                    </div>

                    <div class="mb-3 col-4">
                        <label for="cpf" class="form-label">
                        <span>CPF</span>
                        </label>
                        <input type="cpf" class="form-control" id="nome completo" placeholder="Digite seu CPF" name="cpf">
                    </div>

                    <div class="mb-3 col-4">
                        <label for="date" class="form-label">
                        <span>Nome</span>
                        </label>
                        <input type="date" class="form-control" id="dtnasc" placeholder="Data de nascimento" name="dtnasc">
                    </div>

                    <div class="mb-3 col-4">
                        <label for="email" class="form-label">
                        <span>Email</span>
                        </label>
                        <input type="email" class="form-control" id="email" placeholder="Digite seu email" name="email">
                    </div>

                    <div class="mb-3 col-4">
                        <label for="password" class="form-label">
                        <span>Senha</span>
                        </label>
                        <input type="password" class="form-control" id="senha" placeholder="Digite sua senha" name="senha">
                    </div>



                    <div class="mb-3 col-7 text-center">
                        <button type="submit" class="btn btn-outline-primary">
                            <span class="iconify" data-icon="fluent:send-20-filled">
                                Enviar Dados
                            </span>
                        </button>
                    </div>
                </form>
            </div>
          </div>
        </div>
    </div>