<div class="row">

                <h3>Dados do Triângulo<br></h3>

                <form action="receba-exercicio04.php" method="POST">

                    <div class="mb-3 col-2">
                        <label for="number" class="form-label">
                        <span>LADO 1</span>
                        </label>
                        <input type="number" class="form-control" id="lado1" placeholder="Digite o valor" name="lado1">
                    </div>

                    <div class="mb-3 col-2">
                        <label for="number" class="form-label">
                        <span>LADO 2</span>
                        </label>
                        <input type="number" class="form-control" id="lado2" placeholder="Digite o valor" name="lado2">
                    </div>

                    <div class="mb-3 col-2">
                        <label for="number" class="form-label">
                        <span>LADO 3</span>
                        </label>
                        <input type="number" class="form-control" id="lado3" placeholder="Digite o valor" name="lado3">
                    </div>


                    <div class="mb-3 col-6 text-center">
                        <button type="submit" class="btn btn-outline-primary">
                            <span class="iconify" data-icon="fluent:send-20-filled">
                                Resultado
                            </span>
                        </button>
                    </div>
                </form>
            </div>