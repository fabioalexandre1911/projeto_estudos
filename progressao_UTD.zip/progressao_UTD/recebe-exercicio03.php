
<?php
    
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    if($email == "fabio@email.com" && $senha == "1234"){
        echo "<h1>Seja bem vindo! Email e senha corretos.";
    }else{
        echo "ERRO: <strong>email ou senha incorreto, Tente novamente!</strong>";
    }

?>