<div class="row">

                <form action="recebe-exercicio03.php" method="POST">

                    <div class="mb-3 col-4">
                        <label for="email" class="form-label">
                        <span>Email</span>
                        </label>
                        <input type="email" class="form-control" id="email" placeholder="Digite seu email" name="email">
                    </div>

                    <div class="mb-3 col-4">
                        <label for="password" class="form-label">
                        <span>Senha</span>
                        </label>
                        <input type="password" class="form-control" id="senha" placeholder="Digite sua senha" name="senha">
                    </div>



                    <div class="mb-3 col-7 text-center">
                        <button type="submit" class="btn btn-outline-primary">
                            <span class="iconify" data-icon="fluent:send-20-filled">
                                Enviar Dados
                            </span>
                        </button>
                    </div>
                </form>
            </div>