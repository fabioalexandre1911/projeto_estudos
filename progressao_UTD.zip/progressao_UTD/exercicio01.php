
<?php

    $res = array(0,0,0,0,0,0,0,0,0,0);
    for ($i=0;$i<1000000;$i++) {
          $n = rand(0,100000);
        if ($n<=9) {
          $res[$n]++;
        }
    }

    print_r($res);

    $array = $res;
    echo "<br><br>";
    echo "<strong>O array</strong> tem ".count($array). " elementos! <br>";

    function somaArray($array){
        $total = 0;
        foreach($array as $a){
            $total += $a;
        }

        return $total;
    }

    echo "<strong>A soma</strong> dos valores do <strong>array</strong> é ". somaArray($array)."! <br>";

    echo "<strong>A média</strong> dos valores do <strong>array</strong> é ". (somaArray($array)/count($array))."! <br>";
    

?>


